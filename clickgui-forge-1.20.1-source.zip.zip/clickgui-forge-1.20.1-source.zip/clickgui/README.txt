BUDOWA .JAR
1. Skopiuj gradlew, gradlew.bat, gradle/ i gradle.properties z Forge MDK 1.20.1-47.2.0 (files.minecraftforge.net) do tego folderu.
2. Java 17.   ./gradlew build
3. Gotowy mod: build/libs/clickgui-1.20.1-1.0.0-all.jar  (zawiera LuaJ)  -> wrzuc do .minecraft/mods (Forge 1.20.1).
   Test bez budowania jara: ./gradlew runClient

W GRZE: Prawy Shift = menu.
LUA:   .minecraft/clickgui/scripts/*.lua  (przyklad example.lua tworzy sie sam). Zakladka Scripts: Import z schowka, Reload, Delete, Open folder.
CFG:   .minecraft/clickgui/configs/<nazwa>.cfg.  Zakladka Configs: Save / Load / Delete. "default" laduje sie sam przy starcie.

API LUA:
  register_callback("tick"|"hud"|"unload", function() ... end)
  client.log(s)  client.chat(s)  client.time_ms()
  player.x() y() z() yaw() pitch() health() on_ground()  player.set_rotation(yaw, pitch)
  world.mobs(range) -> tablica {id,name,x,y,z,health,max_health,hostile,distance}
  menu.checkbox(name, def) / menu.slider(name, min, max, def) / menu.combo(name, {opcje}, def)  -> h:get() / h:set(v)
  menu.button(name, function() ... end)
  render.text(x, y, tekst, 0xAARRGGBB)  render.rect(x, y, w, h, 0xAARRGGBB)  render.screen_size()   (render.* tylko w "hud")
Sandbox: brak io, os, require, dofile, luajava.

TACZ (Timeless and Classics Zero)
  Ragebot -> sekcja "Guns": TaCZ Support, Gun Range (do 128), Auto Reload.
  Gdy trzymasz bron z TaCZ, Ragebot celuje w moby w Gun Range i strzela przez API TaCZ (Silent Aim dziala tez dla broni).
  Integracja jest przez refleksje (klasy com.tacz.guns.api.item.IGun i com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator).
  Jesli w logu pojawi sie "nie znalazlem jego API", Twoja wersja TaCZ ma inne nazwy - wklej log, dostosuje.
