package com.example.clickgui;

import net.minecraft.Util;
import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.nio.file.Files;

public class ScriptsPage extends Module {
    private final Setting.Text name = new Setting.Text("Script name", "myscript");

    public ScriptsPage() {
        super("Scripts", "Miscellaneous", "Add / manage");
        refresh();
    }

    @Override public void onOpen() { refresh(); }

    private void importClipboard() {
        String code = Minecraft.getInstance().keyboardHandler.getClipboard();
        String n = Config.sanitize(name.value);
        if (n == null || code == null || code.isBlank()) return;
        try {
            Files.writeString(Config.scriptsDir().resolve(n + ".lua"), code);
            ScriptManager.load(n + ".lua");
        } catch (IOException ignored) {}
        refresh();
    }

    public void refresh() {
        sections.clear();
        Section a = section("Add / manage", 0);
        a.add(name);
        a.add(new Setting.Button("Paste Lua from clipboard", "Import", this::importClipboard));
        a.add(new Setting.Button("Open scripts folder", "Open", () -> Util.getPlatform().openFile(Config.scriptsDir().toFile())));
        a.add(new Setting.Button("Reload all scripts", "Reload", () -> { ScriptManager.loadAll(); refresh(); }));

        Section b = section("Script files", 1);
        var files = ScriptManager.files();
        if (files.isEmpty()) b.add(new Setting.Label(() -> "No .lua files"));
        for (String f : files)
            b.add(new Setting.Button(f, "Reload", () -> { ScriptManager.load(f); refresh(); },
                    "Delete", () -> { ScriptManager.delete(f); refresh(); }));
    }
}
