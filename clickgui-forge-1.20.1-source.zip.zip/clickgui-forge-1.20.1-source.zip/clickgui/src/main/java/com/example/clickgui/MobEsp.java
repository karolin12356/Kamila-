package com.example.clickgui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.debug.DebugRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/** ESP + chams (przyblizone - wypelnione boxy) + radar, tylko dla mobow. */
public class MobEsp extends Module {
    private static final String[] COLORS = {"Red", "Orange", "Yellow", "Green", "Cyan", "Blue", "Purple", "White"};
    private static final float[][] RGB = {
            {1f, .2f, .2f}, {1f, .6f, .1f}, {1f, 1f, .2f}, {.2f, 1f, .3f},
            {.2f, 1f, 1f}, {.25f, .5f, 1f}, {.7f, .3f, 1f}, {1f, 1f, 1f}};

    private final Setting.Bool throughWalls = new Setting.Bool("Through Walls", true);
    private final Setting.Combo tracers = new Setting.Combo("Tracers", "Disabled", "Disabled", "Crosshair");
    private final Setting.Bool radar = new Setting.Bool("In-Game Radar", false);
    private final Setting.Bool hostileOnly = new Setting.Bool("Hostile Only", false);
    private final Setting.Slider radius = new Setting.Slider("Radius", 8, 128, 64, "");

    private final Setting.Bool chams = new Setting.Bool("Enable Chams", false);
    private final Setting.Bool chamsWalls = new Setting.Bool("Through Walls", true);
    private final Setting.Slider opacity = new Setting.Slider("Opacity", 5, 80, 25, "%");

    private final Setting.Combo hostileColor = new Setting.Combo("Hostile Color", "Red", COLORS);
    private final Setting.Combo passiveColor = new Setting.Combo("Passive Color", "Green", COLORS);

    public MobEsp() {
        super("Mob ESP", "Visuals", "ESP", "Enable ESP");
        main.add(throughWalls).add(tracers).add(radar).add(hostileOnly).add(radius);
        section("Chams", 1).add(chams).add(chamsWalls).add(opacity);
        section("Colors", 1).add(hostileColor).add(passiveColor);
    }

    private List<Mob> mobs(Minecraft mc) {
        List<Mob> out = new ArrayList<>();
        double r2 = radius.value * radius.value;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof Mob m) || !m.isAlive()) continue;
            if (hostileOnly.value && !(m instanceof Enemy)) continue;
            if (mc.player.distanceToSqr(m) > r2) continue;
            out.add(m);
        }
        return out;
    }

    private float[] color(Mob m) {
        return RGB[(m instanceof Enemy ? hostileColor : passiveColor).index];
    }

    @Override
    public void onRenderWorld(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        if (!enabled() && !chams.value) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        List<Mob> list = mobs(mc);
        if (list.isEmpty()) return;

        PoseStack ps = e.getPoseStack();
        Vec3 cam = e.getCamera().getPosition();
        float pt = e.getPartialTick();
        MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();

        if (chams.value) {
            float a = (float) opacity.value / 100f;
            for (Mob m : list) {
                float[] c = color(m);
                DebugRenderer.renderFilledBox(ps, bs, box(m, cam, pt), c[0], c[1], c[2], a);
            }
            if (chamsWalls.value) RenderSystem.disableDepthTest();
            bs.endBatch(RenderType.debugFilledBox());
            RenderSystem.enableDepthTest();
        }

        if (enabled()) {
            VertexConsumer vc = bs.getBuffer(RenderType.lines());
            PoseStack.Pose pose = ps.last();
            Vector3f look = e.getCamera().getLookVector();
            for (Mob m : list) {
                float[] c = color(m);
                AABB box = box(m, cam, pt);
                LevelRenderer.renderLineBox(ps, vc, box, c[0], c[1], c[2], 1f);
                if (tracers.is("Crosshair")) {
                    Vec3 ctr = box.getCenter();
                    Vec3 dir = ctr.subtract(look.x(), look.y(), look.z()).normalize();
                    vc.vertex(pose.pose(), look.x(), look.y(), look.z()).color(c[0], c[1], c[2], 1f)
                            .normal(pose.normal(), (float) dir.x, (float) dir.y, (float) dir.z).endVertex();
                    vc.vertex(pose.pose(), (float) ctr.x, (float) ctr.y, (float) ctr.z).color(c[0], c[1], c[2], 1f)
                            .normal(pose.normal(), (float) dir.x, (float) dir.y, (float) dir.z).endVertex();
                }
            }
            if (throughWalls.value) RenderSystem.disableDepthTest();
            RenderSystem.lineWidth(2f);
            bs.endBatch(RenderType.lines());
            RenderSystem.enableDepthTest();
        }
    }

    private static AABB box(Mob m, Vec3 cam, float pt) {
        double ox = Mth.lerp(pt, m.xo, m.getX()) - m.getX();
        double oy = Mth.lerp(pt, m.yo, m.getY()) - m.getY();
        double oz = Mth.lerp(pt, m.zo, m.getZ()) - m.getZ();
        return m.getBoundingBox().move(ox - cam.x, oy - cam.y, oz - cam.z);
    }

    @Override
    public void onRenderHud(GuiGraphics g) {
        if (!enabled() || !radar.value) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.options.hideGui) return;

        int size = 90, x0 = 10, y0 = 10, cx = x0 + size / 2, cy = y0 + size / 2;
        g.fill(x0, y0, x0 + size, y0 + size, 0x90000000);
        g.fill(cx, y0, cx + 1, y0 + size, 0x30FFFFFF);
        g.fill(x0, cy, x0 + size, cy + 1, 0x30FFFFFF);
        g.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);

        double yaw = Math.toRadians(p.getYRot());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        double scale = (size / 2.0 - 3) / radius.value;
        for (Mob m : mobs(mc)) {
            double dx = m.getX() - p.getX(), dz = m.getZ() - p.getZ();
            int px = cx + (int) ((dx * rx + dz * rz) * scale);
            int py = cy - (int) ((dx * fx + dz * fz) * scale);
            if (px < x0 + 1 || px > x0 + size - 2 || py < y0 + 1 || py > y0 + size - 2) continue;
            float[] c = color(m);
            int argb = 0xFF000000 | ((int) (c[0] * 255) << 16) | ((int) (c[1] * 255) << 8) | (int) (c[2] * 255);
            g.fill(px - 1, py - 1, px + 2, py + 2, argb);
        }
    }
}
