package com.example.clickgui;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ModuleManager {
    public static final List<Module> MODULES = new CopyOnWriteArrayList<>();

    public static void init() {
        MODULES.add(new RageBot());
        AntiAim.INSTANCE = new AntiAim();
        MODULES.add(AntiAim.INSTANCE);
        MODULES.add(new MobEsp());
        MODULES.add(new ScriptsPage());
        MODULES.add(new ConfigsPage());
        Config.load("default");   // jesli istnieje
        ScriptManager.init();     // laduje skrypty .lua i nakłada na nie config
    }
}
