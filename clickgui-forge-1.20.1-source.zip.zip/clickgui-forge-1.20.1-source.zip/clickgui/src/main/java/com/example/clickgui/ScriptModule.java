package com.example.clickgui;

import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LoadState;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaFunction;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.compiler.LuaC;
import org.luaj.vm2.lib.Bit32Lib;
import org.luaj.vm2.lib.StringLib;
import org.luaj.vm2.lib.TableLib;
import org.luaj.vm2.lib.VarArgFunction;
import org.luaj.vm2.lib.jse.JseBaseLib;
import org.luaj.vm2.lib.jse.JseMathLib;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Jeden skrypt Lua = jedna zakladka w menu. Sandbox: brak io / os / luajava / debug / require / dofile.
 * API: client, player, world, menu, render, register_callback(event, fn)  (eventy: tick, hud, unload)
 */
public class ScriptModule extends Module {
    private static final org.slf4j.Logger LOG = LogUtils.getLogger();

    public final String file;
    private final Map<String, List<LuaFunction>> callbacks = new HashMap<>();
    private Section custom;
    private String error = "";
    private GuiGraphics gfx;

    public ScriptModule(String file) {
        super(file, "Scripts", "Script", "Enabled");
        this.file = file;
        section("Status", 1).add(new Setting.Label(() -> error.isEmpty() ? "Status: OK" : "Error: " + error));
    }

    private Section custom() {
        if (custom == null) custom = section("Script settings", 0);
        return custom;
    }

    // ---------------------------------------------------------------- ladowanie
    public void load(Path path) {
        try {
            String code = Files.readString(path);
            Globals g = sandbox();
            g.load(code, "@" + file).call();
        } catch (IOException e) {
            error = "cannot read file";
        } catch (Exception e) {
            setError(e);
        }
    }

    public void unloadScript() {
        try { fireAlways("unload"); } catch (Exception ignored) {}
        callbacks.clear();
    }

    private void setError(Exception e) {
        String m = String.valueOf(e.getMessage()).split("\n")[0];
        error = m.length() > 200 ? m.substring(0, 200) : m;
        LOG.warn("[lua:{}] {}", file, m);
    }

    // ---------------------------------------------------------------- callbacki
    private void fireAlways(String ev) {
        List<LuaFunction> l = callbacks.get(ev);
        if (l == null) return;
        for (LuaFunction f : l) {
            try { f.call(); } catch (Exception e) { setError(e); }
        }
    }

    @Override public void onTick(Minecraft mc) { if (enabled()) fireAlways("tick"); }

    @Override
    public void onRenderHud(GuiGraphics g) {
        if (!enabled()) return;
        gfx = g;
        fireAlways("hud");
        gfx = null;
    }

    // ---------------------------------------------------------------- sandbox + API
    private static LuaValue fn(Function<Varargs, Varargs> f) {
        return new VarArgFunction() {
            @Override public Varargs invoke(Varargs a) { return f.apply(a); }
        };
    }

    private static LuaTable handle(Supplier<LuaValue> get, Consumer<LuaValue> set) {
        LuaTable t = new LuaTable();
        t.set("get", fn(a -> get.get()));                       // dziala jako t:get() i t.get()
        t.set("set", fn(a -> { set.accept(a.arg(a.narg() >= 2 ? 2 : 1)); return LuaValue.NONE; }));
        return t;
    }

    private static Minecraft mc() { return Minecraft.getInstance(); }

    private Globals sandbox() {
        Globals g = new Globals();
        g.load(new JseBaseLib());
        g.load(new Bit32Lib());
        g.load(new TableLib());
        g.load(new StringLib());
        g.load(new JseMathLib());
        LoadState.install(g);
        LuaC.install(g);
        g.set("dofile", LuaValue.NIL);
        g.set("loadfile", LuaValue.NIL);
        g.set("print", fn(a -> { LOG.info("[lua:{}] {}", file, a.arg(1).tojstring()); return LuaValue.NONE; }));

        g.set("register_callback", fn(a -> {
            callbacks.computeIfAbsent(a.checkjstring(1), k -> new ArrayList<>()).add(a.checkfunction(2));
            return LuaValue.NONE;
        }));

        // client
        LuaTable client = new LuaTable();
        client.set("log", fn(a -> { LOG.info("[lua:{}] {}", file, a.arg(1).tojstring()); return LuaValue.NONE; }));
        client.set("chat", fn(a -> {
            LocalPlayer p = mc().player;
            if (p != null) p.displayClientMessage(Component.literal(a.arg(1).tojstring()), false);
            return LuaValue.NONE;
        }));
        client.set("time_ms", fn(a -> LuaValue.valueOf((double) System.currentTimeMillis())));
        g.set("client", client);

        // player
        LuaTable player = new LuaTable();
        player.set("x", fn(a -> mc().player == null ? LuaValue.NIL : LuaValue.valueOf(mc().player.getX())));
        player.set("y", fn(a -> mc().player == null ? LuaValue.NIL : LuaValue.valueOf(mc().player.getY())));
        player.set("z", fn(a -> mc().player == null ? LuaValue.NIL : LuaValue.valueOf(mc().player.getZ())));
        player.set("yaw", fn(a -> mc().player == null ? LuaValue.NIL : LuaValue.valueOf((double) mc().player.getYRot())));
        player.set("pitch", fn(a -> mc().player == null ? LuaValue.NIL : LuaValue.valueOf((double) mc().player.getXRot())));
        player.set("health", fn(a -> mc().player == null ? LuaValue.NIL : LuaValue.valueOf((double) mc().player.getHealth())));
        player.set("on_ground", fn(a -> mc().player == null ? LuaValue.NIL : LuaValue.valueOf(mc().player.onGround())));
        player.set("set_rotation", fn(a -> {
            LocalPlayer p = mc().player;
            if (p != null) { p.setYRot((float) a.checkdouble(1)); p.setXRot((float) Math.max(-90, Math.min(90, a.checkdouble(2)))); }
            return LuaValue.NONE;
        }));
        g.set("player", player);

        // world
        LuaTable world = new LuaTable();
        world.set("mobs", fn(a -> {
            LuaTable out = new LuaTable();
            Minecraft m = mc();
            if (m.level == null || m.player == null) return out;
            double r = a.optdouble(1, 32);
            int i = 1;
            for (Entity e : m.level.entitiesForRendering()) {
                if (!(e instanceof Mob mob) || !mob.isAlive()) continue;
                double d = m.player.distanceTo(mob);
                if (d > r) continue;
                LuaTable t = new LuaTable();
                t.set("id", LuaValue.valueOf(mob.getId()));
                t.set("name", LuaValue.valueOf(mob.getName().getString()));
                t.set("x", LuaValue.valueOf(mob.getX()));
                t.set("y", LuaValue.valueOf(mob.getY()));
                t.set("z", LuaValue.valueOf(mob.getZ()));
                t.set("health", LuaValue.valueOf((double) mob.getHealth()));
                t.set("max_health", LuaValue.valueOf((double) mob.getMaxHealth()));
                t.set("hostile", LuaValue.valueOf(mob instanceof Enemy));
                t.set("distance", LuaValue.valueOf(d));
                out.set(i++, t);
            }
            return out;
        }));
        g.set("world", world);

        // menu
        LuaTable menu = new LuaTable();
        menu.set("checkbox", fn(a -> {
            Setting.Bool b = new Setting.Bool(a.checkjstring(1), a.optboolean(2, false));
            custom().add(b);
            return handle(() -> LuaValue.valueOf(b.value), v -> b.value = v.toboolean());
        }));
        menu.set("slider", fn(a -> {
            Setting.Slider s = new Setting.Slider(a.checkjstring(1), a.checkdouble(2), a.checkdouble(3),
                    a.optdouble(4, a.checkdouble(2)), "");
            custom().add(s);
            return handle(() -> LuaValue.valueOf(s.value), v -> s.value = Math.max(s.min, Math.min(s.max, v.todouble())));
        }));
        menu.set("combo", fn(a -> {
            LuaTable t = a.checktable(2);
            List<String> opts = new ArrayList<>();
            for (int i = 1; i <= t.length(); i++) opts.add(t.get(i).tojstring());
            if (opts.isEmpty()) opts.add("-");
            Setting.Combo c = new Setting.Combo(a.checkjstring(1), a.optjstring(3, opts.get(0)), opts.toArray(new String[0]));
            custom().add(c);
            return handle(() -> LuaValue.valueOf(c.get()), v -> c.load(v.tojstring()));
        }));
        menu.set("button", fn(a -> {
            LuaFunction cb = a.checkfunction(2);
            custom().add(new Setting.Button(a.checkjstring(1), "Run", () -> {
                try { cb.call(); } catch (Exception e) { setError(e); }
            }));
            return LuaValue.NONE;
        }));
        g.set("menu", menu);

        // render (tylko w callbacku "hud")
        LuaTable render = new LuaTable();
        render.set("text", fn(a -> {
            if (gfx != null) gfx.drawString(mc().font, a.arg(3).tojstring(), a.checkint(1), a.checkint(2), (int) a.optlong(4, 0xFFFFFFFFL), true);
            return LuaValue.NONE;
        }));
        render.set("rect", fn(a -> {
            if (gfx != null) {
                int x = a.checkint(1), y = a.checkint(2);
                gfx.fill(x, y, x + a.checkint(3), y + a.checkint(4), (int) a.optlong(5, 0xFFFFFFFFL));
            }
            return LuaValue.NONE;
        }));
        render.set("screen_size", fn(a -> LuaValue.varargsOf(
                LuaValue.valueOf(mc().getWindow().getGuiScaledWidth()),
                LuaValue.valueOf(mc().getWindow().getGuiScaledHeight()))));
        g.set("render", render);
        return g;
    }
}
