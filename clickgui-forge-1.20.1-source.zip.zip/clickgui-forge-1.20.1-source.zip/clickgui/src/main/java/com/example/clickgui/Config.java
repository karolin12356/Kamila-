package com.example.clickgui;

import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/** Configi: .minecraft/clickgui/configs/<nazwa>.cfg   Skrypty: .minecraft/clickgui/scripts/*.lua */
public class Config {
    public static String current = "default";
    private static Properties last = new Properties();

    private static Path dir(String sub) {
        Path p = FMLPaths.GAMEDIR.get().resolve("clickgui").resolve(sub);
        try { Files.createDirectories(p); } catch (IOException ignored) {}
        return p;
    }
    public static Path cfgDir() { return dir("configs"); }
    public static Path scriptsDir() { return dir("scripts"); }

    /** Zostawia tylko litery, cyfry, _ i -. Zwraca null, gdy nic nie zostalo. */
    public static String sanitize(String s) {
        if (s == null) return null;
        String r = s.trim().replaceAll("[^A-Za-z0-9_\\-]", "");
        if (r.isEmpty()) return null;
        return r.length() > 32 ? r.substring(0, 32) : r;
    }

    public static List<String> list() {
        try (Stream<Path> s = Files.list(cfgDir())) {
            return s.map(p -> p.getFileName().toString())
                    .filter(n -> n.endsWith(".cfg"))
                    .map(n -> n.substring(0, n.length() - 4))
                    .sorted().collect(Collectors.toList());
        } catch (IOException e) { return List.of(); }
    }

    private static String key(Module m, Setting s) { return m.name + "." + s.name; }

    public static boolean save(String rawName) {
        String name = sanitize(rawName);
        if (name == null) return false;
        Properties p = new Properties();
        for (Module m : ModuleManager.MODULES)
            for (Module.Section sec : m.sections)
                for (Setting st : sec.settings) {
                    String v = st.save();
                    if (v != null) p.setProperty(key(m, st), v);
                }
        try (OutputStream out = Files.newOutputStream(cfgDir().resolve(name + ".cfg"))) {
            p.store(out, "Click GUI config");
        } catch (IOException e) { return false; }
        last = p;
        current = name;
        return true;
    }

    public static boolean load(String rawName) {
        String name = sanitize(rawName);
        if (name == null) return false;
        Path f = cfgDir().resolve(name + ".cfg");
        if (!Files.exists(f)) return false;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(f)) { p.load(in); } catch (IOException e) { return false; }
        last = p;
        current = name;
        for (Module m : ModuleManager.MODULES) applyTo(m);
        return true;
    }

    public static boolean delete(String rawName) {
        String name = sanitize(rawName);
        if (name == null) return false;
        try { return Files.deleteIfExists(cfgDir().resolve(name + ".cfg")); } catch (IOException e) { return false; }
    }

    /** Nakłada wartosci z ostatnio wczytanego configu (uzywane tez dla swiezo zaladowanych skryptow). */
    public static void applyTo(Module m) {
        for (Module.Section sec : m.sections)
            for (Setting st : sec.settings) {
                if (st.save() == null) continue;
                String v = last.getProperty(key(m, st));
                if (v != null) st.load(v);
            }
    }
}
