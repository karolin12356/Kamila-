package com.example.clickgui;

import net.minecraftforge.fml.common.Mod;

@Mod(ClickGuiMod.MODID)
public class ClickGuiMod {
    public static final String MODID = "clickgui";
    public ClickGuiMod() {
        ModuleManager.init();
    }
}
