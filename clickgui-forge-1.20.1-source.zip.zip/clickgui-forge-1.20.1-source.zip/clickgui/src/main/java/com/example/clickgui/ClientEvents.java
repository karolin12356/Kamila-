package com.example.clickgui;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public class ClientEvents {
    public static final KeyMapping OPEN_GUI = new KeyMapping(
            "Open Click GUI", InputConstants.KEY_RSHIFT, "Click GUI");

    @Mod.EventBusSubscriber(modid = ClickGuiMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ModBus {
        @SubscribeEvent
        public static void keys(RegisterKeyMappingsEvent e) { e.register(OPEN_GUI); }
    }

    @Mod.EventBusSubscriber(modid = ClickGuiMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static class ForgeBus {
        @SubscribeEvent
        public static void tick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            while (OPEN_GUI.consumeClick()) {
                if (mc.screen == null) mc.setScreen(new ClickGuiScreen());
            }
            if (mc.player == null) return;
            for (Module m : ModuleManager.MODULES) m.onTick(mc);
        }

        @SubscribeEvent
        public static void renderWorld(RenderLevelStageEvent e) {
            for (Module m : ModuleManager.MODULES) m.onRenderWorld(e);
        }

        @SubscribeEvent
        public static void hud(RenderGuiOverlayEvent.Post e) {
            if (e.getOverlay() != VanillaGuiOverlay.HOTBAR.type()) return;
            for (Module m : ModuleManager.MODULES) m.onRenderHud(e.getGuiGraphics());
        }

        @SubscribeEvent
        public static void livingPre(RenderLivingEvent.Pre<?, ?> e) {
            if (AntiAim.INSTANCE != null) AntiAim.INSTANCE.pre(e);
        }

        @SubscribeEvent
        public static void livingPost(RenderLivingEvent.Post<?, ?> e) {
            if (AntiAim.INSTANCE != null) AntiAim.INSTANCE.post(e);
        }
    }
}
