package com.example.clickgui;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.RenderLivingEvent;

/** Wszystko tylko wizualne (render Twojej postaci, widac w F5). Prawdziwy obrot i pozycja sie nie zmieniaja. */
public class AntiAim extends Module {
    public static AntiAim INSTANCE;

    private final Setting.Combo pitch = new Setting.Combo("Pitch", "Disabled", "Disabled", "Down", "Up", "Zero", "Jitter");
    private final Setting.Combo yawBase = new Setting.Combo("Yaw Base", "Forward", "Forward", "Backward", "Spin");
    private final Setting.Slider yawAdd = new Setting.Slider("Yaw Add", -180, 180, 0, "\u00B0");
    private final Setting.Combo yawMod = new Setting.Combo("Yaw Modifier", "Disabled", "Disabled", "Jitter", "Random");
    private final Setting.Slider jitterRange = new Setting.Slider("Jitter Range", 0, 90, 30, "\u00B0");
    private final Setting.Slider spinSpeed = new Setting.Slider("Spin Speed", 1, 60, 20, "");

    private final Setting.Bool fakeLag = new Setting.Bool("Enable Fake Lag", false);
    private final Setting.Slider lagLimit = new Setting.Slider("Limit", 1, 14, 14, "");
    private final Setting.Slider lagRand = new Setting.Slider("Randomization", 0, 14, 0, "");

    private final Setting.Bool fakeAngle = new Setting.Bool("Enable Fake Angle", false);
    private final Setting.Bool inverter = new Setting.Bool("Inverter", false);
    private final Setting.Slider leftLimit = new Setting.Slider("Left Limit", 0, 60, 60, "");
    private final Setting.Slider rightLimit = new Setting.Slider("Right Limit", 0, 60, 60, "");

    private boolean applied;
    private float bodyRot, bodyRotO, headRot, headRotO, xRot, xRotO;
    private Vec3 lagPos;
    private int lagCounter;

    public AntiAim() {
        super("Anti Aim", "Aimbot", "Main", "Enable Anti Aim");
        main.add(pitch).add(yawBase).add(yawAdd).add(yawMod).add(jitterRange).add(spinSpeed);
        section("Fake Lag", 0).add(fakeLag).add(lagLimit).add(lagRand);
        section("Fake Angle", 1).add(fakeAngle).add(inverter).add(leftLimit).add(rightLimit);
    }

    @Override
    public void onTick(Minecraft mc) {
        if (!enabled() || !fakeLag.value || mc.player == null) { lagPos = null; return; }
        if (lagPos == null || --lagCounter <= 0) {
            lagPos = mc.player.position();
            lagCounter = lagLimit.asInt() + (int) (Math.random() * (lagRand.asInt() + 1));
        }
    }

    public void pre(RenderLivingEvent.Pre<?, ?> e) {
        LivingEntity ent = e.getEntity();
        if (!enabled() || ent != Minecraft.getInstance().player) return;

        bodyRot = ent.yBodyRot; bodyRotO = ent.yBodyRotO;
        headRot = ent.yHeadRot; headRotO = ent.yHeadRotO;
        xRot = ent.getXRot(); xRotO = ent.xRotO;
        applied = true;

        PoseStack ps = e.getPoseStack();
        ps.pushPose();
        if (fakeLag.value && lagPos != null) {
            double pt = e.getPartialTick();
            ps.translate(lagPos.x - Mth.lerp(pt, ent.xo, ent.getX()),
                         lagPos.y - Mth.lerp(pt, ent.yo, ent.getY()),
                         lagPos.z - Mth.lerp(pt, ent.zo, ent.getZ()));
        }

        long t = System.currentTimeMillis();
        boolean yawActive = !yawBase.is("Forward") || yawAdd.asInt() != 0 || !yawMod.is("Disabled") || fakeAngle.value;
        if (yawActive) {
            float yaw = ent.getYRot();
            if (yawBase.is("Backward")) yaw += 180f;
            else if (yawBase.is("Spin")) yaw = (float) ((t * spinSpeed.value * 0.02) % 360.0);
            yaw += (float) yawAdd.value;
            if (yawMod.is("Jitter")) yaw += ((t / 100) % 2 == 0 ? 1 : -1) * (float) jitterRange.value;
            else if (yawMod.is("Random")) yaw += (float) ((Math.random() * 2 - 1) * jitterRange.value);

            float head = yaw, body = yaw;
            if (fakeAngle.value) body = head + (float) (inverter.value ? -leftLimit.value : rightLimit.value);
            ent.yHeadRot = ent.yHeadRotO = head;
            ent.yBodyRot = ent.yBodyRotO = body;
        }

        if (!pitch.is("Disabled")) {
            float px = pitch.is("Down") ? 90f : pitch.is("Up") ? -90f : pitch.is("Zero") ? 0f
                    : ((t / 100) % 2 == 0 ? 90f : -90f);
            ent.setXRot(px);
            ent.xRotO = px;
        }
    }

    public void post(RenderLivingEvent.Post<?, ?> e) {
        LivingEntity ent = e.getEntity();
        if (!applied || ent != Minecraft.getInstance().player) return;
        ent.yBodyRot = bodyRot; ent.yBodyRotO = bodyRotO;
        ent.yHeadRot = headRot; ent.yHeadRotO = headRotO;
        ent.setXRot(xRot); ent.xRotO = xRotO;
        e.getPoseStack().popPose();
        applied = false;
    }
}
