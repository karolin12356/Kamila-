package com.example.clickgui;

import java.util.List;

public class ConfigsPage extends Module {
    private final Setting.Text name = new Setting.Text("Name", "myconfig");

    public ConfigsPage() {
        super("Configs", "Miscellaneous", "Config");
        refresh();
    }

    @Override public void onOpen() { refresh(); }

    public void refresh() {
        sections.clear();
        Section a = section("Config", 0);
        a.add(new Setting.Label(() -> "Current: " + Config.current));
        a.add(name);
        a.add(new Setting.Button("Save / create", "Save", () -> { Config.save(name.value); refresh(); }));

        Section b = section("Saved configs", 1);
        List<String> list = Config.list();
        if (list.isEmpty()) b.add(new Setting.Label(() -> "No configs yet"));
        for (String n : list)
            b.add(new Setting.Button(n, "Load", () -> Config.load(n), "Delete", () -> { Config.delete(n); refresh(); }));
    }
}
