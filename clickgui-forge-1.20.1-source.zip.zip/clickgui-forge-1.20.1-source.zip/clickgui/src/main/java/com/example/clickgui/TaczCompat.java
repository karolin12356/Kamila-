package com.example.clickgui;

import com.mojang.logging.LogUtils;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraftforge.fml.ModList;

import java.lang.reflect.Method;

/**
 * Miekka integracja z Timeless and Classics Zero (modId "tacz") przez refleksje,
 * wiec mod kompiluje sie i dziala tez bez TaCZ.
 * Uzywane klasy TaCZ: api.item.IGun, api.client.gameplay.IClientPlayerGunOperator (fromLocalPlayer, shoot, reload).
 */
public final class TaczCompat {
    private static final org.slf4j.Logger LOG = LogUtils.getLogger();
    private static boolean inited, available;
    private static Class<?> iGun;
    private static Method fromLocalPlayer, shootM, reloadM;

    private TaczCompat() {}

    private static void init() {
        if (inited) return;
        inited = true;
        try {
            if (!ModList.get().isLoaded("tacz")) return;
            iGun = Class.forName("com.tacz.guns.api.item.IGun");
            Class<?> op = Class.forName("com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator");
            fromLocalPlayer = op.getMethod("fromLocalPlayer", LocalPlayer.class);
            shootM = op.getMethod("shoot");
            reloadM = op.getMethod("reload");
            available = true;
            LOG.info("[clickgui] TaCZ wykryty - integracja broni aktywna");
        } catch (Throwable t) {
            LOG.warn("[clickgui] TaCZ jest zaladowany, ale nie znalazlem jego API ({}). Integracja wylaczona.", t.toString());
        }
    }

    public static boolean available() { init(); return available; }

    public static boolean holdingGun(LocalPlayer p) {
        init();
        return available && iGun.isInstance(p.getMainHandItem().getItem());
    }

    /**
     * Strzal z bronii TaCZ w podanym kierunku. Przy silent=true serwer dostaje obrot na celu,
     * a Twoja kamera zostaje na miejscu (obrot wraca w tym samym ticku).
     * Zwraca nazwe ShootResult (np. "SUCCESS", "NO_AMMO", "COOL_DOWN") albo null przy bledzie.
     */
    public static String shoot(LocalPlayer p, float yaw, float pitch, boolean silent) {
        if (!available()) return null;
        float oy = p.getYRot(), ox = p.getXRot();
        try {
            if (silent) {
                p.connection.send(new ServerboundMovePlayerPacket.Rot(yaw, pitch, p.onGround()));
                p.setYRot(yaw);
                p.setXRot(pitch);
            }
            Object operator = fromLocalPlayer.invoke(null, p);
            Object result = shootM.invoke(operator);
            return result == null ? null : result.toString();
        } catch (Throwable t) {
            LOG.warn("[clickgui] TaCZ shoot() failed: {}", t.toString());
            return null;
        } finally {
            if (silent) {
                p.setYRot(oy);
                p.setXRot(ox);
                p.connection.send(new ServerboundMovePlayerPacket.Rot(oy, ox, p.onGround()));
            }
        }
    }

    public static void reload(LocalPlayer p) {
        if (!available()) return;
        try {
            reloadM.invoke(fromLocalPlayer.invoke(null, p));
        } catch (Throwable t) {
            LOG.warn("[clickgui] TaCZ reload() failed: {}", t.toString());
        }
    }
}
