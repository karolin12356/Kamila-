package com.example.clickgui;

import net.minecraft.SharedConstants;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;

public class ClickGuiScreen extends Screen {
    private static final int BG = 0xF0101720, SIDE = 0xF00B1016, ACCENT = 0xFF1E9BFF, OFF = 0xFF3A4350,
            TEXT = 0xFFE6EDF7, DIM = 0xFF8A97A8, SELECTED = 0xFF1B2A3D, PANEL = 0xFF0C1219, BOX = 0xFF121B26,
            ROW = 17;
    private static final int CLIP_NONE = 0, CLIP_CONTENT = 1, CLIP_SIDE = 2;

    private record Hit(int x1, int y1, int x2, int y2, int clip, IntConsumer click,
                       Setting.Slider slider, int tx, int tw) {
        boolean in(double x, double y) { return x >= x1 && x <= x2 && y >= y1 && y <= y2; }
    }

    private final List<Hit> hits = new ArrayList<>();
    private static Module selected;
    private static int scroll, sideScroll;
    private static Setting.Combo openCombo;
    private static Setting.Text focused;
    private Hit dragging;
    private int contentH, contentTop, contentBottom, sideH, sideTop, sideBottom, guiX, guiSide;
    private long savedAt;
    private Setting.Combo popupCombo;
    private int popupX, popupY, popupW;

    public ClickGuiScreen() { super(Component.literal("Click GUI")); }

    @Override public boolean isPauseScreen() { return false; }

    private void select(Module m) {
        selected = m; scroll = 0; openCombo = null; focused = null;
        m.onOpen();
    }

    private void toggle(GuiGraphics g, int x, int y, boolean on) {
        g.fill(x, y, x + 22, y + 9, on ? 0x701E9BFF : OFF);
        int kx = on ? x + 13 : x + 1;
        g.fill(kx, y + 1, kx + 8, y + 8, on ? ACCENT : DIM);
    }

    private void hit(int x1, int y1, int x2, int y2, int clip, IntConsumer click) {
        hits.add(new Hit(x1, y1, x2, y2, clip, click, null, 0, 0));
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        hits.clear();
        popupCombo = null;
        if (selected == null || !ModuleManager.MODULES.contains(selected)) select(ModuleManager.MODULES.get(0));

        int w = Math.min(560, width - 20), h = Math.min(330, height - 20), side = 110;
        int x = (width - w) / 2, y = (height - h) / 2;
        guiX = x; guiSide = side;
        g.fill(x, y, x + w, y + h, BG);
        g.fill(x, y, x + side, y + h, SIDE);
        g.drawString(font, "NEVERLOSE", x + 12, y + 11, 0xFFFFFFFF, true);

        // ---- sidebar (ze scrollem)
        sideTop = y + 30; sideBottom = y + h - 4;
        sideH = 0;
        sideScroll = Math.max(0, Math.min(sideScroll, Math.max(0, lastSideH - (sideBottom - sideTop))));
        g.enableScissor(x, sideTop, x + side, sideBottom);
        int sy = sideTop + 6 - sideScroll;
        String lastGroup = null;
        for (Module m : ModuleManager.MODULES) {
            if (!m.group.equals(lastGroup)) {
                g.drawString(font, m.group, x + 12, sy, 0xFF566273, false);
                sy += 14;
                lastGroup = m.group;
            }
            boolean sel = m == selected;
            if (sel) g.fill(x + 5, sy - 3, x + side - 5, sy + 12, SELECTED);
            String label = font.plainSubstrByWidth(m.name, side - 26);
            g.drawString(font, label, x + 14, sy + 1, sel ? ACCENT : DIM, false);
            hit(x, sy - 3, x + side, sy + 12, CLIP_SIDE, b -> select(m));
            sy += 19;
        }
        lastSideH = sy + sideScroll - sideTop;
        g.disableScissor();

        // ---- gorny pasek
        int bx = x + side + 10;
        g.fill(bx, y + 7, bx + 62, y + 23, 0xFF0D131B);
        g.drawString(font, "Save", bx + 18, y + 11, TEXT, false);
        hit(bx, y + 7, bx + 62, y + 23, CLIP_NONE, b -> { Config.save(Config.current); savedAt = System.currentTimeMillis(); });
        boolean justSaved = System.currentTimeMillis() - savedAt < 1500;
        g.drawString(font, justSaved ? "Saved: " + Config.current : "Config: " + Config.current,
                bx + 72, y + 11, justSaved ? ACCENT : DIM, false);

        // ---- zawartosc
        int cx0 = x + side + 10, cx1 = x + w - 10;
        contentTop = y + 30; contentBottom = y + h - 8;
        int colW = (cx1 - cx0 - 10) / 2;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, contentH - (contentBottom - contentTop))));

        g.enableScissor(cx0 - 2, contentTop, cx1 + 2, contentBottom);
        int[] colY = {contentTop - scroll, contentTop - scroll};
        for (Module.Section s : selected.sections) {
            int sx = cx0 + s.col * (colW + 10), top = colY[s.col];
            int ph = 22 + s.settings.size() * (int) ROW + 2;
            g.fill(sx, top, sx + colW, top + ph, PANEL);
            g.drawString(font, s.title, sx + 8, top + 6, 0xFFC9D4E3, false);
            g.fill(sx + 6, top + 17, sx + colW - 6, top + 18, 0xFF1A2A3C);
            int ry = top + 24;
            for (Setting st : s.settings) { drawSetting(g, st, sx, ry, colW); ry += (int) ROW; }
            colY[s.col] += ph + 8;
        }
        contentH = Math.max(colY[0], colY[1]) + scroll - contentTop;
        g.disableScissor();

        // ---- popup dropdownu
        if (popupCombo != null) {
            Setting.Combo c = popupCombo;
            int n = c.options.length, ph = n * 13 + 2;
            g.fill(popupX, popupY, popupX + popupW, popupY + ph, 0xFF0A1118);
            for (int i = 0; i < n; i++) {
                int oy = popupY + 1 + i * 13;
                g.drawString(font, c.options[i], popupX + 5, oy + 2, i == c.index ? ACCENT : TEXT, false);
                final int idx = i;
                hit(popupX, oy, popupX + popupW, oy + 13, CLIP_NONE, b -> { c.index = idx; openCombo = null; });
            }
        }
        super.render(g, mx, my, pt);
    }

    private int lastSideH;

    private void smallButton(GuiGraphics g, int bx, int ry, int bw, String label, Runnable action) {
        g.fill(bx, ry - 3, bx + bw, ry + 10, BOX);
        g.drawString(font, label, bx + (bw - font.width(label)) / 2, ry, ACCENT, false);
        hit(bx, ry - 3, bx + bw, ry + 10, CLIP_CONTENT, b -> { if (b == 0) action.run(); });
    }

    private void drawSetting(GuiGraphics g, Setting st, int sx, int ry, int colW) {
        int rowTop = ry - 4, rowBot = ry + 13;
        if (st instanceof Setting.Label l) {
            String t = font.plainSubstrByWidth(l.text.get(), colW - 16);
            g.drawString(font, t, sx + 8, ry, t.startsWith("Error") ? 0xFFFF6B6B : DIM, false);
            return;
        }
        if (st instanceof Setting.Button b) {
            int labelW = b.label2 != null ? colW - 126 : colW - 80;
            g.drawString(font, font.plainSubstrByWidth(b.name, labelW), sx + 8, ry, TEXT, false);
            if (b.label2 != null) {
                smallButton(g, sx + colW - 8 - 48, ry, 48, b.label2, b.action2);
                smallButton(g, sx + colW - 8 - 48 - 4 - 48, ry, 48, b.label1, b.action1);
            } else {
                smallButton(g, sx + colW - 8 - 56, ry, 56, b.label1, b.action1);
            }
            return;
        }
        g.drawString(font, font.plainSubstrByWidth(st.name, colW - 130), sx + 8, ry, TEXT, false);
        if (st instanceof Setting.Bool b) {
            toggle(g, sx + colW - 32, ry - 1, b.value);
            hit(sx, rowTop, sx + colW, rowBot, CLIP_CONTENT, btn -> { if (btn == 0) b.value = !b.value; });
        } else if (st instanceof Setting.Slider sl) {
            int tx = sx + colW - 118, tw = 72;
            double f = (sl.value - sl.min) / (sl.max - sl.min);
            g.fill(tx, ry + 3, tx + tw, ry + 5, OFF);
            g.fill(tx, ry + 3, tx + (int) (tw * f), ry + 5, ACCENT);
            g.fill(tx + (int) (tw * f) - 2, ry, tx + (int) (tw * f) + 2, ry + 8, ACCENT);
            g.drawString(font, sl.asInt() + sl.suffix, tx + tw + 6, ry, DIM, false);
            hits.add(new Hit(tx - 3, rowTop, tx + tw + 3, rowBot, CLIP_CONTENT, null, sl, tx, tw));
        } else if (st instanceof Setting.Combo c) {
            int bw = 96, bxx = sx + colW - bw - 8;
            g.fill(bxx, ry - 3, bxx + bw, ry + 10, BOX);
            g.drawString(font, font.plainSubstrByWidth(c.get(), bw - 16), bxx + 5, ry, TEXT, false);
            g.drawString(font, "v", bxx + bw - 9, ry, DIM, false);
            hit(bxx, ry - 3, bxx + bw, ry + 10, CLIP_CONTENT, btn -> openCombo = (openCombo == c) ? null : c);
            if (openCombo == c) { popupCombo = c; popupX = bxx; popupY = ry + 10; popupW = bw; }
        } else if (st instanceof Setting.Text t) {
            int bw = 110, bxx = sx + colW - bw - 8;
            g.fill(bxx, ry - 3, bxx + bw, ry + 10, focused == t ? 0xFF1B2A3D : BOX);
            String shown = t.value + (focused == t && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
            g.drawString(font, font.plainSubstrByWidth(shown, bw - 8, true), bxx + 4, ry, TEXT, false);
            hit(bxx, ry - 3, bxx + bw, ry + 10, CLIP_CONTENT, btn -> focused = t);
        }
    }

    private void drag(Hit h, double mx) {
        double f = Math.max(0, Math.min(1, (mx - h.tx) / h.tw));
        h.slider.value = Math.round(h.slider.min + f * (h.slider.max - h.slider.min));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (btn == 0 || btn == 1) {
            Setting.Combo prevCombo = openCombo;
            Setting.Text prevFocus = focused;
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (!h.in(mx, my)) continue;
                if (h.clip == CLIP_CONTENT && (my < contentTop || my > contentBottom)) continue;
                if (h.clip == CLIP_SIDE && (my < sideTop || my > sideBottom)) continue;
                if (h.slider != null) { if (btn == 0) { dragging = h; drag(h, mx); } }
                else h.click.accept(btn);
                if (openCombo == prevCombo) openCombo = null;
                if (focused == prevFocus) focused = null;
                return true;
            }
            openCombo = null;
            focused = null;
        }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (dragging != null) { drag(dragging, mx); return true; }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        dragging = null;
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (mx < guiX + guiSide) sideScroll -= (int) (delta * 20);
        else scroll -= (int) (delta * 20);
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (focused != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                focused = null;
            } else if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!focused.value.isEmpty()) focused.value = focused.value.substring(0, focused.value.length() - 1);
            } else if (Screen.isPaste(key) && minecraft != null) {
                String v = focused.value + minecraft.keyboardHandler.getClipboard();
                focused.value = v.length() > 32 ? v.substring(0, 32) : v;
            }
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (focused != null) {
            if (SharedConstants.isAllowedChatCharacter(c) && focused.value.length() < 32) focused.value += c;
            return true;
        }
        return super.charTyped(c, mods);
    }
}
