package com.example.clickgui;

import java.util.function.Supplier;

public abstract class Setting {
    public final String name;
    protected Setting(String name) { this.name = name; }
    /** null = nie zapisywac w configu */
    public abstract String save();
    public abstract void load(String s);

    public static class Bool extends Setting {
        public boolean value;
        public Bool(String name, boolean def) { super(name); this.value = def; }
        @Override public String save() { return String.valueOf(value); }
        @Override public void load(String s) { value = Boolean.parseBoolean(s); }
    }

    public static class Slider extends Setting {
        public final double min, max;
        public final String suffix;
        public double value;
        public Slider(String name, double min, double max, double def, String suffix) {
            super(name); this.min = min; this.max = max; this.value = def; this.suffix = suffix;
        }
        public int asInt() { return (int) Math.round(value); }
        @Override public String save() { return Double.toString(value); }
        @Override public void load(String s) {
            try { value = Math.max(min, Math.min(max, Double.parseDouble(s))); } catch (NumberFormatException ignored) {}
        }
    }

    public static class Combo extends Setting {
        public final String[] options;
        public int index;
        public Combo(String name, String def, String... options) {
            super(name); this.options = options;
            for (int i = 0; i < options.length; i++) if (options[i].equals(def)) index = i;
        }
        public String get() { return options[index]; }
        public boolean is(String s) { return options[index].equals(s); }
        @Override public String save() { return get(); }
        @Override public void load(String s) {
            for (int i = 0; i < options.length; i++) if (options[i].equals(s)) index = i;
        }
    }

    /** Tekst tylko do wyswietlenia. */
    public static class Label extends Setting {
        public final Supplier<String> text;
        public Label(Supplier<String> text) { super(""); this.text = text; }
        @Override public String save() { return null; }
        @Override public void load(String s) {}
    }

    /** Pole tekstowe (nie zapisywane w configu). */
    public static class Text extends Setting {
        public String value;
        public Text(String name, String def) { super(name); this.value = def; }
        @Override public String save() { return null; }
        @Override public void load(String s) {}
    }

    /** Wiersz z 1 lub 2 przyciskami. */
    public static class Button extends Setting {
        public final String label1, label2;
        public final Runnable action1, action2;
        public Button(String name, String label1, Runnable action1) { this(name, label1, action1, null, null); }
        public Button(String name, String label1, Runnable action1, String label2, Runnable action2) {
            super(name); this.label1 = label1; this.action1 = action1; this.label2 = label2; this.action2 = action2;
        }
        @Override public String save() { return null; }
        @Override public void load(String s) {}
    }
}
