package com.example.clickgui;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ScriptManager {
    private static final String EXAMPLE = """
            -- Przyklad skryptu. Wlacz go w menu: lewy pasek -> example.lua -> Enabled.
            local show  = menu.checkbox("Show mob count", true)
            local range = menu.slider("Range", 4, 64, 24)
            local msg   = menu.combo("Style", {"Plain", "Fancy"}, "Plain")

            register_callback("hud", function()
              if not show:get() then return end
              local n = #world.mobs(range:get())
              local text = "Mobs nearby: " .. n
              if msg:get() == "Fancy" then text = "[ " .. text .. " ]" end
              render.text(10, 110, text, 0xFFFFFFFF)
            end)
            """;

    public static void init() {
        Path ex = Config.scriptsDir().resolve("example.lua");
        if (!Files.exists(ex)) {
            try { Files.writeString(ex, EXAMPLE); } catch (IOException ignored) {}
        }
        loadAll();
    }

    public static List<String> files() {
        try (Stream<Path> s = Files.list(Config.scriptsDir())) {
            List<String> out = new ArrayList<>();
            s.forEach(p -> { String n = p.getFileName().toString(); if (n.endsWith(".lua")) out.add(n); });
            out.sort(String::compareTo);
            return out;
        } catch (IOException e) { return List.of(); }
    }

    public static void loadAll() {
        for (Module m : ModuleManager.MODULES)
            if (m instanceof ScriptModule s) unload(s.file);
        for (String f : files()) load(f);
    }

    public static void load(String file) {
        unload(file);
        ScriptModule m = new ScriptModule(file);
        m.load(Config.scriptsDir().resolve(file));
        Config.applyTo(m);
        ModuleManager.MODULES.add(m);
    }

    public static void unload(String file) {
        for (Module m : ModuleManager.MODULES)
            if (m instanceof ScriptModule s && s.file.equals(file)) {
                s.unloadScript();
                ModuleManager.MODULES.remove(m);
            }
    }

    public static void delete(String file) {
        unload(file);
        try { Files.deleteIfExists(Config.scriptsDir().resolve(file)); } catch (IOException ignored) {}
    }
}
