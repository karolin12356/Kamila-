package com.example.clickgui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.client.event.RenderLevelStageEvent;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public static class Section {
        public final String title;
        public final int col;
        public final List<Setting> settings = new ArrayList<>();
        Section(String title, int col) { this.title = title; this.col = col; }
        public Section add(Setting s) { settings.add(s); return this; }
    }

    public final String name, group;
    public final List<Section> sections = new ArrayList<>();
    public final Setting.Bool enabledSetting; // null dla stron (Configs/Scripts)
    protected final Section main;

    protected Module(String name, String group, String mainTitle, String enabledLabel) {
        this.name = name;
        this.group = group;
        this.enabledSetting = new Setting.Bool(enabledLabel, false);
        this.main = section(mainTitle, 0);
        this.main.add(enabledSetting);
    }

    /** Konstruktor dla stron bez przelacznika Enabled. */
    protected Module(String name, String group, String mainTitle) {
        this.name = name;
        this.group = group;
        this.enabledSetting = null;
        this.main = section(mainTitle, 0);
    }

    protected Section section(String title, int col) {
        Section s = new Section(title, col);
        sections.add(s);
        return s;
    }

    public boolean enabled() { return enabledSetting != null && enabledSetting.value; }

    /** Wywolywane gdy modul/strona zostaje wybrana w GUI. */
    public void onOpen() {}
    public void onTick(Minecraft mc) {}
    public void onRenderWorld(RenderLevelStageEvent e) {}
    public void onRenderHud(GuiGraphics g) {}
}
