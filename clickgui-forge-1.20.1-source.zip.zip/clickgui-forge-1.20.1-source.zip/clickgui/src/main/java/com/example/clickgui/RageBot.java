package com.example.clickgui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.Vec3;

/** Aimbot tylko na moby (gracze sa pomijani - Player nie jest Mob). Obsluguje bron z TaCZ. */
public class RageBot extends Module {
    // Main
    private final Setting.Bool silent = new Setting.Bool("Silent Aim", true);
    private final Setting.Bool autoFire = new Setting.Bool("Automatic Fire", true);
    private final Setting.Bool penetrate = new Setting.Bool("Penetrate Walls", false);
    private final Setting.Slider fov = new Setting.Slider("Field of View", 1, 180, 180, "\u00B0");
    // Selection
    private final Setting.Combo targetMode = new Setting.Combo("Target", "Near Crosshair", "Near Crosshair", "Closest", "Lowest Health");
    private final Setting.Combo hitbox = new Setting.Combo("Hitboxes", "Chest", "Head", "Chest", "Legs");
    private final Setting.Bool multipoint = new Setting.Bool("Multipoint", false);
    private final Setting.Slider hitChance = new Setting.Slider("Hit Chance", 0, 100, 100, "%");
    private final Setting.Slider minDamage = new Setting.Slider("Min Damage", 0, 20, 1, "");
    private final Setting.Bool autoStop = new Setting.Bool("Auto Stop", false);
    // Other
    private final Setting.Slider range = new Setting.Slider("Range", 2, 6, 4, "");
    private final Setting.Slider smoothing = new Setting.Slider("Smoothing", 1, 20, 3, "");
    private final Setting.Bool hostileOnly = new Setting.Bool("Hostile Only", true);
    private final Setting.Bool delayShot = new Setting.Bool("Delay Shot", true);
    // Guns (TaCZ)
    private final Setting.Bool taczSupport = new Setting.Bool("TaCZ Support", true);
    private final Setting.Slider gunRange = new Setting.Slider("Gun Range", 5, 128, 64, "");
    private final Setting.Bool autoReload = new Setting.Bool("Auto Reload", true);

    public RageBot() {
        super("Ragebot", "Aimbot", "Main", "Enabled");
        main.add(silent).add(autoFire).add(penetrate).add(fov);
        section("Selection", 0).add(targetMode).add(hitbox).add(multipoint).add(hitChance).add(minDamage).add(autoStop);
        section("Other", 1).add(range).add(smoothing).add(hostileOnly).add(delayShot);
        section("Guns (Timeless & Classics Zero)", 1).add(taczSupport).add(gunRange).add(autoReload)
                .add(new Setting.Label(() -> TaczCompat.available() ? "TaCZ: detected" : "TaCZ: not found"));
    }

    private static double angleTo(LocalPlayer p, Vec3 point) {
        Vec3 to = point.subtract(p.getEyePosition()).normalize();
        return Math.toDegrees(Math.acos(Mth.clamp(p.getViewVector(1f).dot(to), -1, 1)));
    }

    private Mob findTarget(Minecraft mc, LocalPlayer p, double maxRange) {
        Mob best = null;
        double bestScore = Double.MAX_VALUE, r2 = maxRange * maxRange;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof Mob m) || !m.isAlive()) continue;
            if (hostileOnly.value && !(m instanceof Enemy)) continue;
            double d2 = p.distanceToSqr(m);
            if (d2 > r2) continue;
            if (!penetrate.value && !p.hasLineOfSight(m)) continue;
            double ang = angleTo(p, m.getBoundingBox().getCenter());
            if (ang > fov.value) continue;
            double score = targetMode.is("Closest") ? d2 : targetMode.is("Lowest Health") ? m.getHealth() : ang;
            if (score < bestScore) { bestScore = score; best = m; }
        }
        return best;
    }

    private Vec3 aimPoint(Mob t) {
        Vec3 pt;
        if (hitbox.is("Head")) pt = t.getEyePosition();
        else if (hitbox.is("Legs")) pt = new Vec3(t.getX(), t.getY() + t.getBbHeight() * 0.2, t.getZ());
        else pt = new Vec3(t.getX(), t.getY() + t.getBbHeight() * 0.6, t.getZ());
        if (multipoint.value) {
            double w = t.getBbWidth() * 0.3;
            pt = pt.add((Math.random() * 2 - 1) * w, 0, (Math.random() * 2 - 1) * w);
        }
        return pt;
    }

    @Override
    public void onTick(Minecraft mc) {
        if (!enabled()) return;
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null) return;

        boolean gun = taczSupport.value && TaczCompat.holdingGun(p);
        Mob t = findTarget(mc, p, gun ? gunRange.value : range.value);
        if (t == null) return;

        Vec3 eye = p.getEyePosition(), aim = aimPoint(t);
        double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
        float yaw = (float) (Mth.atan2(dz, dx) * 57.2957795) - 90f;
        float pitch = (float) -(Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 57.2957795);

        if (!silent.value) {
            float s = (float) smoothing.value;
            p.setYRot(p.getYRot() + Mth.wrapDegrees(yaw - p.getYRot()) / s);
            p.setXRot(Mth.clamp(p.getXRot() + (pitch - p.getXRot()) / s, -90f, 90f));
        }

        boolean wantFire = autoFire.value || mc.options.keyAttack.isDown();
        boolean aligned = silent.value
                || (Math.abs(Mth.wrapDegrees(yaw - p.getYRot())) < 8f && Math.abs(pitch - p.getXRot()) < 8f);
        if (!wantFire || !aligned) return;
        if (Math.random() * 100 > hitChance.value) return;

        if (gun) {
            if (autoStop.value) p.setDeltaMovement(0, p.getDeltaMovement().y, 0);
            String result = TaczCompat.shoot(p, yaw, pitch, silent.value);
            if (autoReload.value && "NO_AMMO".equals(result)) TaczCompat.reload(p);
            return;
        }

        // bron biala / piesc
        if (p.getAttributeValue(Attributes.ATTACK_DAMAGE) < minDamage.value) return;
        if (p.getAttackStrengthScale(0.5f) < (delayShot.value ? 1f : 0.2f)) return;
        if (autoStop.value) p.setDeltaMovement(0, p.getDeltaMovement().y, 0);

        if (silent.value)
            p.connection.send(new ServerboundMovePlayerPacket.Rot(yaw, pitch, p.onGround()));
        mc.gameMode.attack(p, t);
        p.swing(InteractionHand.MAIN_HAND);
        if (silent.value)
            p.connection.send(new ServerboundMovePlayerPacket.Rot(p.getYRot(), p.getXRot(), p.onGround()));
    }
}
